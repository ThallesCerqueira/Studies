public class Painel {

    private String listaProfessores;
    private String listaAlunos;
    private String listaCandidaturas;

    public void defedirCandidatura() {}

    public void cancelarCandidatura() {}

    public void listaAlunos() {}

    public void listarProfessores() {}

    public void listaCandidaturas() {}

}
