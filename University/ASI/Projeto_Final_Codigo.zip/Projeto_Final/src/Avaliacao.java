public class Avaliacao {

    private float nota;

    // Não entendi o atributo Disciplina

    public void fazerAvaliacao() {}

    public void abrirContestacao() {}

}
