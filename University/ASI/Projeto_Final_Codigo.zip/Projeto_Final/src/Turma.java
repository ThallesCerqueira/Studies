public class Turma {

    private int id;
    private Aluno listaAlunos;
    private String disciplina;
    private String processor;


}
