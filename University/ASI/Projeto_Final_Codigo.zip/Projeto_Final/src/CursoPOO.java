public class CursoPOO extends Curso{

    public CursoPOO() {
        super();
        setNome("Curso POO");
    }
}
