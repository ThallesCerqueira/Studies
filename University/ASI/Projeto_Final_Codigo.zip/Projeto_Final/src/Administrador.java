public class Administrador  {

    private String historicoAcesso;

    public void setHistoricoAcesso(String historicoAcesso) {
        this.historicoAcesso = historicoAcesso;
    }

    public String getHistoricoAcesso() {
        return historicoAcesso;
    }

    public void hubAdm() {

    }
}
