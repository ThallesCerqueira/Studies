public class Aula {

    private int codigo;
    private String titulo;
    private String descricao;
    private int duracaoHrs;
    private String status;

    // Não entendi o atributo Disciplina

    public void assistirAula() {

    }

    public void gravarAula() {

    }

}
