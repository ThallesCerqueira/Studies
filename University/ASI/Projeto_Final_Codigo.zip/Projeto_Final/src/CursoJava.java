public class CursoJava extends Curso {
    public CursoJava() {
        super();
        setNome("Curso de Java");
    }
}
