public class Professor extends Usuario {

    private Disciplina listaDisciplinas;
    private Turma listaTurmas;

    public void hubProf() {

    }

}