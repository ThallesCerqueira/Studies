public class Candidatura {

    private String planoEnsino;

    // não entendi os atributos Professor, Curso, Disciplina

    public void realizarCandidatura() {}

}
