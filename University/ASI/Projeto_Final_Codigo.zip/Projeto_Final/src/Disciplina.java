public class Disciplina {

    private int id;
    private String nome;
    private String descricao;

    // sem entender atributos professor e curso

}
