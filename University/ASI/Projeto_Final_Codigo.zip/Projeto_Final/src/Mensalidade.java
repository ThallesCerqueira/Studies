public class Mensalidade {

    private float valor;
    private int parcela;
    private String formaPagamento;
    private String status;

    public void efetuarPagamento() {}

}
