import java.util.Date;

public class Usuario {
    private int id;
    private String nome;
    private String email;
    private String senha;
    private Date dataCadastro;
    private String endereco;

    public void efetuarLogin() {}

}
