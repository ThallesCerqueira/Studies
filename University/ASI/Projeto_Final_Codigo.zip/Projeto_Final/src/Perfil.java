import java.awt.*;

public class Perfil {

    private Image foto;
    private String descricao;
    private String formacaoAcademica;

    public void editarPerfil() {}

}
